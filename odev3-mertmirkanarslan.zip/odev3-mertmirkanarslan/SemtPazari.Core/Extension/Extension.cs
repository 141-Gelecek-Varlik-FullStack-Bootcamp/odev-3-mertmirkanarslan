﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SemtPazari.Core.Extension
{
    public static class Extension
    {
        //Core katmanı yerine modelde kullanıldı.
        //public static void toGMTTimeZone(this DateTime turkishTime)
        //{
        //    
        //}


    }
}
