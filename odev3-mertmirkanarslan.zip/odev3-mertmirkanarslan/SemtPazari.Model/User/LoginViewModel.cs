﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SemtPazari.Model.User
{
    public class LoginViewModel
    {
<<<<<<< HEAD
        //Loginde kullanılacak view model. Yalnızca kullanıcı adı ve şifre bilgisi istiyor.
        public string UserName { get; set; }
=======
        //Kullanıcı girişinde kullanılacak olan view model. sadece kullanıcı adı ve şifre yeterli olacaktır.
        public string Username { get; set; }
>>>>>>> 4b0ce1aa505d15dfb16d08ce6c31d8678a5e72f2
        public string Password { get; set; }
    }
}
